import unittest
from unittest.mock import patch, mock_open, call
import os

from odoo_wizard_generator import (
    OdooModuleGenerator, DirectoryManager, FileManager, InitFileBuilder,
    ManifestBuilder, ModelBuilder, ViewBuilder, SecurityBuilder
)

class TestOdooModuleGenerator(unittest.TestCase):

    @patch('os.makedirs')
    def test_create_directory_structure(self, mock_makedirs):
        directory_manager = DirectoryManager('test_module')
        directory_manager.create_directory_structure()
        expected_calls = [
            call(os.path.join('test_module', 'models'), exist_ok=True),
            call(os.path.join('test_module', 'views'), exist_ok=True),
            call(os.path.join('test_module', 'security'), exist_ok=True)
        ]
        mock_makedirs.assert_has_calls(expected_calls, any_order=True)

    @patch('builtins.open', new_callable=mock_open)
    def test_write_file(self, mock_file):
        file_manager = FileManager('test_module')
        file_manager.write_file('test_path', 'test_content')
        mock_file.assert_called_once_with('test_path', 'w')
        mock_file().write.assert_called_once_with('test_content')

    def test_generate_module(self):
        generator = OdooModuleGenerator('test_module')
        generator.model_names = ['test_model']
        generator.model_fields = {'test_model': {'field1': 'Char', 'field2': 'Text'}}

        with patch.object(DirectoryManager, 'create_directory_structure') as mock_create_dirs, \
             patch.object(InitFileBuilder, 'build_module_init') as mock_build_module_init, \
             patch.object(InitFileBuilder, 'build_models_init') as mock_build_models_init, \
             patch.object(ManifestBuilder, 'build_manifest') as mock_build_manifest, \
             patch.object(ModelBuilder, 'build_model_file') as mock_build_model_file, \
             patch.object(ViewBuilder, 'build_view_file') as mock_build_view_file, \
             patch.object(SecurityBuilder, 'build_security_file') as mock_build_security_file:
            
            generator.generate_module()
            
            mock_create_dirs.assert_called_once()
            mock_build_module_init.assert_called_once()
            mock_build_models_init.assert_called_once()
            mock_build_manifest.assert_called_once()
            mock_build_model_file.assert_called_once()
            mock_build_view_file.assert_called_once()
            mock_build_security_file.assert_called_once()

if __name__ == '__main__':
    unittest.main()
