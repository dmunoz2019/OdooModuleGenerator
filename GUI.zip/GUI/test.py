import tkinter as tk
from tkinter import ttk

class ModuleGeneratorApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Odoo Module Generator")
        
        self.main_menu()

    def main_menu(self):
        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Odoo Module Generator", font=("Arial", 18)).pack(pady=10)
        tk.Button(frame, text="Start", command=self.module_info_screen).pack(pady=5)
        tk.Button(frame, text="Help", command=self.help_screen).pack(pady=5)
        tk.Button(frame, text="Exit", command=self.root.quit).pack(pady=5)

    def module_info_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Module Information", font=("Arial", 18)).pack(pady=10)
        
        tk.Label(frame, text="Module Name:").pack(anchor="w")
        self.module_name_entry = tk.Entry(frame)
        self.module_name_entry.pack(fill="x")
        
        tk.Label(frame, text="Version:").pack(anchor="w")
        self.module_version_entry = tk.Entry(frame)
        self.module_version_entry.pack(fill="x")
        
        tk.Label(frame, text="Category:").pack(anchor="w")
        self.module_category_entry = tk.Entry(frame)
        self.module_category_entry.pack(fill="x")
        
        tk.Label(frame, text="Summary:").pack(anchor="w")
        self.module_summary_entry = tk.Entry(frame)
        self.module_summary_entry.pack(fill="x")
        
        tk.Label(frame, text="Dependencies (comma separated):").pack(anchor="w")
        self.module_dependencies_entry = tk.Entry(frame)
        self.module_dependencies_entry.pack(fill="x")
        
        tk.Button(frame, text="Next", command=self.model_info_screen).pack(pady=10)

    def model_info_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Model Information", font=("Arial", 18)).pack(pady=10)

        self.models = []

        tk.Button(frame, text="Add Model", command=self.add_model_screen).pack(pady=5)
        tk.Button(frame, text="Next", command=self.review_screen).pack(pady=10)

    def add_model_screen(self):
        new_model_window = tk.Toplevel(self.root)
        new_model_window.title("Add Model")

        frame = tk.Frame(new_model_window)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Model Name:").pack(anchor="w")
        self.model_name_entry = tk.Entry(frame)
        self.model_name_entry.pack(fill="x")

        self.fields = []

        tk.Button(frame, text="Add Field", command=self.add_field_screen).pack(pady=5)
        tk.Button(frame, text="Save Model", command=self.save_model).pack(pady=10)

    def add_field_screen(self):
        new_field_window = tk.Toplevel(self.root)
        new_field_window.title("Add Field")

        frame = tk.Frame(new_field_window)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Field Name:").pack(anchor="w")
        self.field_name_entry = tk.Entry(frame)
        self.field_name_entry.pack(fill="x")

        tk.Label(frame, text="Field Type:").pack(anchor="w")
        self.field_type_entry = tk.Entry(frame)
        self.field_type_entry.pack(fill="x")

        tk.Button(frame, text="Save Field", command=self.save_field).pack(pady=10)

    def save_model(self):
        model_name = self.model_name_entry.get()
        self.models.append({"name": model_name, "fields": self.fields})
        self.fields = []
        self.model_name_entry.get_toplevel().destroy()

    def save_field(self):
        field_name = self.field_name_entry.get()
        field_type = self.field_type_entry.get()
        self.fields.append({"name": field_name, "type": field_type})
        self.field_name_entry.get_toplevel().destroy()

    def review_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Review and Confirm", font=("Arial", 18)).pack(pady=10)
        
        # Display the collected information for review
        tk.Label(frame, text=f"Module Name: {self.module_name_entry.get()}").pack(anchor="w")
        tk.Label(frame, text=f"Version: {self.module_version_entry.get()}").pack(anchor="w")
        tk.Label(frame, text=f"Category: {self.module_category_entry.get()}").pack(anchor="w")
        tk.Label(frame, text=f"Summary: {self.module_summary_entry.get()}").pack(anchor="w")
        tk.Label(frame, text=f"Dependencies: {self.module_dependencies_entry.get()}").pack(anchor="w")
        
        for model in self.models:
            tk.Label(frame, text=f"Model Name: {model['name']}").pack(anchor="w")
            for field in model["fields"]:
                tk.Label(frame, text=f"  Field Name: {field['name']}, Field Type: {field['type']}").pack(anchor="w")

        tk.Button(frame, text="Confirm", command=self.generate_module).pack(pady=10)
        tk.Button(frame, text="Back", command=self.model_info_screen).pack(pady=5)

    def generate_module(self):
        # Logic to generate the module based on collected data
        # For now, just display a message
        for widget in self.root.winfo_children():
            widget.destroy()

        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Module generated successfully!", font=("Arial", 18)).pack(pady=10)
        tk.Button(frame, text="Main Menu", command=self.main_menu).pack(pady=10)
        tk.Button(frame, text="Exit", command=self.root.quit).pack(pady=5)

    def help_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        frame = tk.Frame(self.root)
        frame.pack(padx=10, pady=10)

        tk.Label(frame, text="Help/Documentation", font=("Arial", 18)).pack(pady=10)
        tk.Label(frame, text="Instructions on how to use the Odoo Module Generator...").pack(pady=5)
        tk.Button(frame, text="Back", command=self.main_menu).pack(pady=10)


if __name__ == "__main__":
    root = tk.Tk()
    app = ModuleGeneratorApp(root)
    root.mainloop()
